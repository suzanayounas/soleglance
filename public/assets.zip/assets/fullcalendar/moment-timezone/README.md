
# FullCalendar Moment Timezone Plugin

A connector to the moment-timezone library

[View the docs &raquo;](https://fullcalendar.io/docs/moment-plugins#moment-timezone)

This package was created from the [FullCalendar monorepo &raquo;](https://github.com/fullcalendar/fullcalendar)
